"""Mandi Mitra brain: intent parsing (Evon if configured, keyword parser otherwise), data lookups, and Hindi replies."""
import json
import os
import re
from datetime import date

import requests

from hindi_num import to_hindi_words

# ---------- vocab ----------
# spoken word -> Agmarknet commodity name
CROPS = {
    "गेहूं": "Wheat", "गेहूँ": "Wheat", "गेहू": "Wheat", "wheat": "Wheat", "gehu": "Wheat", "gehun": "Wheat",
    "धान": "Paddy(Dhan)(Common)", "paddy": "Paddy(Dhan)(Common)", "dhan": "Paddy(Dhan)(Common)",
    "चावल": "Rice", "rice": "Rice",
    "सरसों": "Mustard", "सरसो": "Mustard", "mustard": "Mustard", "sarson": "Mustard",
    "बाजरा": "Bajra(Pearl Millet/Cumbu)", "बाजरे": "Bajra(Pearl Millet/Cumbu)", "bajra": "Bajra(Pearl Millet/Cumbu)",
    "कपास": "Cotton", "cotton": "Cotton", "kapas": "Cotton", "नरमा": "Cotton",
    "चना": "Bengal Gram(Gram)(Whole)", "चने": "Bengal Gram(Gram)(Whole)", "chana": "Bengal Gram(Gram)(Whole)",
    "प्याज": "Onion", "प्याज़": "Onion", "onion": "Onion", "pyaz": "Onion",
    "आलू": "Potato", "potato": "Potato", "aloo": "Potato",
    "टमाटर": "Tomato", "tomato": "Tomato", "tamatar": "Tomato",
    "मक्का": "Maize", "maize": "Maize", "makka": "Maize",
    "गन्ना": "Sugarcane", "sugarcane": "Sugarcane",
}
CROP_HI = {"Wheat": "गेहूं", "Paddy(Dhan)(Common)": "धान", "Rice": "चावल", "Mustard": "सरसों",
           "Bajra(Pearl Millet/Cumbu)": "बाजरा", "Cotton": "कपास", "Bengal Gram(Gram)(Whole)": "चना",
           "Onion": "प्याज", "Potato": "आलू", "Tomato": "टमाटर", "Maize": "मक्का", "Sugarcane": "गन्ना"}

# spoken word -> (Agmarknet district, state, lat, lon, Hindi name)
PLACES = {
    "रेवाड़ी": ("Rewari", "Haryana", 28.19, 76.62, "रेवाड़ी"), "रेवाडी": ("Rewari", "Haryana", 28.19, 76.62, "रेवाड़ी"),
    "rewari": ("Rewari", "Haryana", 28.19, 76.62, "रेवाड़ी"),
    "झज्जर": ("Jhajjar", "Haryana", 28.61, 76.65, "झज्जर"), "jhajjar": ("Jhajjar", "Haryana", 28.61, 76.65, "झज्जर"),
    "सोनीपत": ("Sonipat", "Haryana", 28.99, 77.02, "सोनीपत"), "sonipat": ("Sonipat", "Haryana", 28.99, 77.02, "सोनीपत"),
    "करनाल": ("Karnal", "Haryana", 29.69, 76.99, "करनाल"), "karnal": ("Karnal", "Haryana", 29.69, 76.99, "करनाल"),
    "हिसार": ("Hissar", "Haryana", 29.15, 75.72, "हिसार"), "hisar": ("Hissar", "Haryana", 29.15, 75.72, "हिसार"),
    "रोहतक": ("Rohtak", "Haryana", 28.89, 76.61, "रोहतक"), "rohtak": ("Rohtak", "Haryana", 28.89, 76.61, "रोहतक"),
    "सिरसा": ("Sirsa", "Haryana", 29.53, 75.03, "सिरसा"), "sirsa": ("Sirsa", "Haryana", 29.53, 75.03, "सिरसा"),
    "जींद": ("Jind", "Haryana", 29.32, 76.31, "जींद"), "jind": ("Jind", "Haryana", 29.32, 76.31, "जींद"),
    "पानीपत": ("Panipat", "Haryana", 29.39, 76.97, "पानीपत"), "panipat": ("Panipat", "Haryana", 29.39, 76.97, "पानीपत"),
    "लुधियाना": ("Ludhiana", "Punjab", 30.90, 75.85, "लुधियाना"), "ludhiana": ("Ludhiana", "Punjab", 30.90, 75.85, "लुधियाना"),
    "ऊना": ("Una", "Himachal Pradesh", 31.47, 76.27, "ऊना"), "una": ("Una", "Himachal Pradesh", 31.47, 76.27, "ऊना"),
    "आगरा": ("Agra", "Uttar Pradesh", 27.18, 78.01, "आगरा"), "agra": ("Agra", "Uttar Pradesh", 27.18, 78.01, "आगरा"),
    "जयपुर": ("Jaipur", "Rajasthan", 26.91, 75.79, "जयपुर"), "jaipur": ("Jaipur", "Rajasthan", 26.91, 75.79, "जयपुर"),
}
DEFAULT_PLACE = PLACES["rewari"]
MARKET_HI = {"Rewari": "रेवाड़ी", "Kosli": "कोसली", "Jhajjar": "झज्जर", "Bahadurgarh": "बहादुरगढ़",
             "Sonipat": "सोनीपत", "Karnal": "करनाल", "Khanna": "खन्ना", "Jagraon": "जगराओं", "Una": "ऊना",
             "Santoshgarh": "संतोषगढ़", "Agra": "आगरा", "Jaipur (Grain)": "जयपुर"}
mk = lambda m: MARKET_HI.get(m, m)  # Devanagari names so Timbre pronounces them well

PRICE_WORDS = ["भाव", "रेट", "दाम", "कीमत", "मंडी", "बिक", "बेच", "rate", "bhav", "price", "mandi", "daam"]
WEATHER_WORDS = ["मौसम", "बारिश", "बरसात", "पानी", "धूप", "ठंड", "गर्मी", "weather", "rain", "barish", "mausam", "सिंचाई"]
DISEASE_WORDS = ["रोग", "बीमारी", "कीड़ा", "कीड़े", "पत्ते", "पीला", "पीली", "सूख", "दवा", "स्प्रे", "keeda", "bimari", "disease"]
SELL_WORDS = ["बेचूं", "बेचू", "बेचना", "रुकूं", "रुकना", "रोकूं", "hold", "sell"]


def _find(text, table):
    t = text.lower()
    for k, v in table.items():
        if k.lower() in t:
            return v
    return None


def parse_keywords(text: str) -> dict:
    t = text.lower()
    has = lambda words: any(w.lower() in t for w in words)
    intent = "unknown"
    if has(DISEASE_WORDS):
        intent = "disease"
    elif has(WEATHER_WORDS):
        intent = "weather"
    elif has(PRICE_WORDS) or has(SELL_WORDS) or _find(text, CROPS):
        intent = "price"
    return {"intent": intent, "crop": _find(text, CROPS), "place": _find(text, PLACES),
            "wants_sell_advice": has(SELL_WORDS), "parser": "keyword"}


EVON_SYSTEM = (
    "You extract intent from an Indian farmer's spoken question. Reply ONLY with JSON: "
    '{"intent": "price|weather|disease|unknown", "crop": "<English crop name or null>", '
    '"district": "<district name in English or null>", "wants_sell_advice": true|false}'
)


def parse_with_evon(text: str):
    url = os.getenv("EVON_URL")
    if not url:
        return None
    try:
        r = requests.post(url.rstrip("/") + "/v1/chat/completions", timeout=25, json={
            "model": os.getenv("EVON_MODEL", "evon"), "temperature": 0,
            "messages": [{"role": "system", "content": EVON_SYSTEM}, {"role": "user", "content": text}]})
        raw = r.json()["choices"][0]["message"]["content"]
        j = json.loads(re.search(r"\{.*\}", raw, re.S).group(0))
        kw = parse_keywords(text)  # map names to our tables, fall back to keyword hits
        crop = _find(j.get("crop") or "", CROPS) or kw["crop"]
        place = _find(j.get("district") or "", PLACES) or kw["place"]
        return {"intent": j.get("intent", kw["intent"]), "crop": crop, "place": place,
                "wants_sell_advice": bool(j.get("wants_sell_advice")), "parser": "evon"}
    except Exception as e:  # never let the LLM break the demo
        print("Evon failed, using keyword parser:", e)
        return None


def understand(text: str) -> dict:
    return parse_with_evon(text) or parse_keywords(text)


# ---------- data ----------
AGMARK = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070"


def mandi_prices(crop: str, place):
    if os.getenv("DEMO_MODE") == "1":
        return demo_prices(crop, place)
    district, state = place[0], place[1]
    key = os.getenv("DATAGOV_API_KEY", "579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b")
    for filters in ({"state.keyword": state, "district": district, "commodity": crop},
                    {"state.keyword": state, "commodity": crop}):
        params = {"api-key": key, "format": "json", "limit": 50}
        params.update({f"filters[{k}]": v for k, v in filters.items()})
        try:
            recs = requests.get(AGMARK, params=params, timeout=20).json().get("records", [])
        except Exception as e:
            print("Agmarknet error:", e)
            recs = []
        if recs:
            recs.sort(key=lambda r: float(r.get("modal_price") or 0), reverse=True)
            return {"source": "live", "records": recs, "district_match": "district" in filters}
    if os.getenv("DEMO_FALLBACK", "1") == "1":
        return demo_prices(crop, place)
    return {"source": "none", "records": []}


# ---------- synthetic demo data (DEMO_MODE=1, or when the live feed is down) ----------
# Challenge rules allow synthetic data only, and a recorded demo must not depend on a rate-limited public key.
# Prices are made up but sit in realistic ranges (Rs/quintal) so the replies sound real.
DEMO_BASE = {"Wheat": 2450, "Mustard": 6150, "Bajra(Pearl Millet/Cumbu)": 2350, "Paddy(Dhan)(Common)": 2300,
             "Cotton": 7200, "Bengal Gram(Gram)(Whole)": 5600, "Onion": 1800, "Potato": 1100, "Tomato": 1500,
             "Maize": 2100, "Rice": 3400, "Sugarcane": 400}
DEMO_MARKETS = {"Haryana": [("Rewari", "Rewari"), ("Kosli", "Rewari"), ("Jhajjar", "Jhajjar"),
                            ("Bahadurgarh", "Jhajjar"), ("Sonipat", "Sonipat"), ("Karnal", "Karnal")],
                "Punjab": [("Khanna", "Ludhiana"), ("Jagraon", "Ludhiana")],
                "Himachal Pradesh": [("Una", "Una"), ("Santoshgarh", "Una")],
                "Uttar Pradesh": [("Agra", "Agra")], "Rajasthan": [("Jaipur (Grain)", "Jaipur")]}


DEMO_NEAR = {"Rewari": ["Rewari", "Kosli", "Jhajjar"], "Jhajjar": ["Jhajjar", "Bahadurgarh", "Kosli"],
             "Sonipat": ["Sonipat", "Bahadurgarh", "Karnal"], "Karnal": ["Karnal", "Sonipat"],
             "Rohtak": ["Bahadurgarh", "Jhajjar", "Sonipat"]}


def demo_prices(crop: str, place):
    import hashlib
    base = DEMO_BASE.get(crop, 2000)
    today = date.today().strftime("%d/%m/%Y")
    recs = []
    for market, dist in DEMO_MARKETS.get(place[1], DEMO_MARKETS["Haryana"]):
        h = int(hashlib.md5(f"{crop}{market}".encode()).hexdigest(), 16)
        modal = round(base * (0.95 + (h % 90) / 1000) / 10) * 10      # +/- ~5% per mandi
        week_ago = round(modal * (0.96 + (h // 7 % 50) / 1000) / 10) * 10
        recs.append({"market": market, "district": dist, "state": place[1], "commodity": crop,
                     "min_price": modal - 120 - h % 80, "max_price": modal + 90 + h % 60,
                     "modal_price": modal, "week_ago_modal": week_ago, "arrival_date": today})
    if place[0] in DEMO_NEAR:  # only mandis a farmer could actually drive to
        recs = [r for r in recs if r["market"] in DEMO_NEAR[place[0]]]
    recs.sort(key=lambda r: r["modal_price"], reverse=True)
    near = sorted([r for r in recs if r["district"] == place[0]], key=lambda r: r["market"] != place[0])
    pick = (near[:1] + [r for r in recs if r not in near[:1]][:2]) if near else recs[:3]
    pick.sort(key=lambda r: r["modal_price"], reverse=True)
    return {"source": "demo", "records": pick, "district_match": bool(near)}


def weather(place):
    try:
        j = requests.get("https://api.open-meteo.com/v1/forecast", timeout=15, params={
            "latitude": place[2], "longitude": place[3], "timezone": "Asia/Kolkata", "forecast_days": 3,
            "daily": "precipitation_sum,precipitation_probability_max,temperature_2m_max,temperature_2m_min"}).json()
        return j["daily"]
    except Exception as e:
        print("Weather error:", e)
        return None


# ---------- replies (Hindi, numbers as words for TTS) ----------
def rs(x):
    return f"{to_hindi_words(float(x))} रुपये"


def answer(text: str) -> dict:
    u = understand(text)
    place = u["place"] or DEFAULT_PLACE
    place_hi = place[4]
    card = {"understood": u, "place": place[0]}

    if u["intent"] == "price":
        if not u["crop"]:
            return {**card, "reply": "किस फसल का भाव जानना है? जैसे गेहूं, धान, सरसों या बाजरा।"}
        crop_hi = CROP_HI.get(u["crop"], u["crop"])
        data = mandi_prices(u["crop"], place)
        if not data["records"]:
            return {**card, "reply": f"माफ़ कीजिए, आज {place_hi} के आसपास {crop_hi} का सरकारी मंडी भाव नहीं मिला। "
                                     "थोड़ी देर बाद फिर पूछिए या पास की दूसरी मंडी का नाम बताइए।"}
        best = data["records"][0]
        top = data["records"][:3]
        card["prices"] = [{"market": r["market"], "district": r["district"], "min": r["min_price"],
                           "max": r["max_price"], "modal": r["modal_price"], "date": r["arrival_date"]} for r in top]
        card["data_source"] = data["source"]
        locals_ = [r for r in data["records"] if r["district"] == place[0]]
        local = next((r for r in locals_ if r["market"] == place[0]), locals_[0] if locals_ else None)
        if local and local is not best and float(best["modal_price"]) - float(local["modal_price"]) < 50:
            reply = (f"{mk(local['market'])} मंडी में आज {crop_hi} का भाव लगभग {rs(local['modal_price'])} प्रति क्विंटल है। "
                     "आसपास की मंडियों में भी लगभग यही भाव है, इसलिए दूर ले जाने का फ़ायदा नहीं।")
        elif local and local is not best:
            gap = float(best["modal_price"]) - float(local["modal_price"])
            reply = (f"{mk(local['market'])} मंडी में आज {crop_hi} का भाव लगभग {rs(local['modal_price'])} प्रति क्विंटल है। "
                     f"पास की {mk(best['market'])} मंडी में {rs(best['modal_price'])} मिल रहा है, "
                     f"यानी {rs(gap)} ज़्यादा।")
        else:
            where = "" if data["district_match"] else f"{place_hi} में आज का भाव नहीं था, इसलिए पूरे राज्य की मंडियां देखीं। "
            reply = (f"{where}{crop_hi} का सबसे अच्छा भाव {mk(best['market'])} मंडी में है, "
                     f"लगभग {rs(best['modal_price'])} प्रति क्विंटल। "
                     f"वहां कम से कम {rs(best['min_price'])} और ज़्यादा से ज़्यादा {rs(best['max_price'])} चल रहा है।")
            if len(top) > 1:
                reply += f" दूसरे नंबर पर {mk(top[1]['market'])} है, {rs(top[1]['modal_price'])}।"
        if u["wants_sell_advice"]:
            ref = local or best
            prev = ref.get("week_ago_modal")
            if prev:
                diff = float(ref["modal_price"]) - float(prev)
                if abs(diff) < 10:
                    reply += " पिछले हफ्ते से भाव लगभग स्थिर है, ज़रूरत हो तो बेच सकते हैं।"
                elif diff > 0:
                    reply += (f" पिछले हफ्ते से भाव {rs(abs(diff))} बढ़ा है। भाव ऊपर जा रहा है, "
                              "अगर भंडारण की जगह है तो कुछ दिन रुक सकते हैं, पर सारी फसल एक साथ न रोकें।")
                else:
                    reply += (f" पिछले हफ्ते से भाव {rs(abs(diff))} घटा है। "
                              "अगर पैसे की ज़रूरत है तो आधी फसल अभी बेच दें और बाकी पर नज़र रखें।")
            reply += " बेचने से पहले भाड़ा जोड़कर देखें।"
        return {**card, "reply": reply}

    if u["intent"] == "weather":
        d = weather(place)
        if not d:
            return {**card, "reply": "अभी मौसम की जानकारी नहीं मिल पाई, थोड़ी देर बाद पूछिए।"}
        card["weather"] = d
        rain = [i for i, p in enumerate(d["precipitation_sum"]) if (p or 0) >= 1]
        days = ["आज", "कल", "परसों"]
        if rain:
            r = days[rain[0]]
            reply = (f"{place_hi} में {r} बारिश की संभावना है। सिंचाई और स्प्रे {r} से पहले न करें, "
                     "कटी हुई फसल ढककर रखें।")
        else:
            reply = (f"{place_hi} में अगले तीन दिन बारिश नहीं दिख रही। दिन का तापमान लगभग "
                     f"{to_hindi_words(d['temperature_2m_max'][0])} डिग्री और रात का "
                     f"{to_hindi_words(d['temperature_2m_min'][0])} डिग्री रहेगा। सिंचाई और स्प्रे के लिए समय ठीक है।")
        return {**card, "reply": reply}

    if u["intent"] == "disease":
        crop_hi = CROP_HI.get(u["crop"], "फसल") if u["crop"] else "फसल"
        return {**card, "reply": (f"{crop_hi} में रोग की सही पहचान के लिए पत्ते की फोटो ज़रूरी है। "
                                  "अभी के लिए खेत में पानी जमा न होने दें और बिना सलाह के दवा न डालें। "
                                  "अपने नज़दीकी कृषि विज्ञान केंद्र से संपर्क करें, या किसान कॉल सेंटर पर मुफ़्त बात करें।")}

    return {**card, "reply": "मैं मंडी भाव, मौसम और फसल की देखभाल में मदद करता हूँ। "
                             "जैसे पूछिए: रेवाड़ी मंडी में सरसों का भाव क्या है?"}


if __name__ == "__main__":
    for q in ["रेवाड़ी मंडी में सरसों का भाव क्या है", "कल झज्जर में बारिश होगी क्या", "गेहूं के पत्ते पीले हो रहे हैं"]:
        print(q, "->", parse_keywords(q))

# 🌾 Mandi Mitra (मंडी मित्र)

A voice assistant for Indian farmers. Ask in Hindi (or Punjabi or Marathi) and hear back today's mandi price, a 3-day rain outlook, or basic crop-care guidance.

Built for the **Gnani AI Great Indian AI Internship Challenge**.

## Pipeline
```
🎤 Browser mic (16 kHz WAV)
   → Gnani Prisma v3.0 (STT, hi-IN / pa-IN / mr-IN / indic-auto, with farming keyterms)
   → Intent: Evon (optional, via EVON_URL) or the keyword parser fallback
   → Data: Agmarknet daily mandi prices (data.gov.in) + Open-Meteo forecast
   → Hindi reply, with numbers written as spoken words
   → Gnani Timbre v3.0 (TTS, voice Shivani) → 🔊
```

## Run
```bash
pip install -r requirements.txt
cp .env.example .env      # paste your GNANI_API_KEY
uvicorn app:app --reload
# open http://localhost:8000, allow the mic, tap 🎤
```

## Demo mode (for the video)
`DEMO_MODE=1` (default in `.env.example`) uses **synthetic mandi prices**: realistic ranges, generated per crop and mandi, labelled "demo data" in the UI. The challenge allows synthetic data only, and the recording never depends on the rate-limited public data.gov.in key. Set `DEMO_MODE=0` for live Agmarknet; if the live feed returns nothing, it falls back to synthetic data (`DEMO_FALLBACK=1`).

Every answer shows a **pipeline trace**: Prisma transcript and detected language, intent, data source, Timbre voice, and the time each stage took. If TTS fails, the text answer still shows.

## Optional: Evon for intent
Serve Evon with an OpenAI-compatible server (llama.cpp `llama-server` with a GGUF quant, or vLLM), then set `EVON_URL=http://host:port`. If Evon fails or isn't set, the keyword parser takes over, so the demo never breaks.

## Notes
- Mandi prices come from the Agmarknet daily feed on data.gov.in. They are not live tick prices.
- Disease advice is general only and points the farmer to the nearest Krishi Vigyan Kendra.
- No real personal data is used. All demo queries are synthetic.

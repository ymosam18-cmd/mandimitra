"""Mandi Mitra: voice mandi-price and weather assistant for farmers.
Pipeline: mic (browser, WAV) -> Gnani Prisma STT -> intent (Evon or keyword parser) -> Agmarknet + Open-Meteo -> Hindi reply -> Gnani Timbre TTS.
Run: pip install -r requirements.txt && uvicorn app:app --reload  (then open http://localhost:8000)
"""
import base64
import os
import time

import requests
from dotenv import load_dotenv
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from brain import answer

load_dotenv()
GNANI = "https://api.vachana.ai"
KEY = lambda: os.getenv("GNANI_API_KEY", "")

app = FastAPI(title="Mandi Mitra")
app.mount("/static", StaticFiles(directory="static"), name="static")


def _post(url, **kw):
    """Gnani allows 1 active request at a time on some accounts, so retry 429s briefly."""
    for i in range(4):
        r = requests.post(url, headers={"X-API-Key-ID": KEY(), **kw.pop("headers", {})}, timeout=60, **kw)
        if r.status_code != 429:
            return r
        time.sleep(0.8 * (i + 1))
    return r


def stt(wav: bytes, lang: str) -> dict:
    r = _post(f"{GNANI}/stt/v3", files={"audio_file": ("q.wav", wav, "audio/wav")},
              data={"model": "prisma-v3.0", "language_code": lang, "format": "transcribe",
                    "topic": "Farmer asking about mandi crop prices, weather and crop disease",
                    "keyterms": '["मंडी","भाव","गेहूं","सरसों","धान","बाजरा","कपास","क्विंटल","रेवाड़ी","झज्जर"]'})
    j = r.json()
    if r.status_code != 200 or not j.get("success", False):
        raise RuntimeError(f"Prisma STT error {r.status_code}: {j}")
    return j


def tts(text: str, lang: str = "hi-IN") -> bytes:
    r = _post(f"{GNANI}/api/v1/tts/inference", json={
        "text": text, "model": "timbre-v3.0", "voice": os.getenv("TIMBRE_VOICE", "Shivani"),
        "language": lang, "speed": 0.95,
        "audio_config": {"sample_rate": 24000, "num_channels": 1, "sample_width": 2,
                         "encoding": "linear_pcm", "container": "mp3", "bitrate": "64k"}})
    if r.status_code != 200 or not r.headers.get("content-type", "").startswith("audio"):
        raise RuntimeError(f"Timbre TTS error {r.status_code}: {r.text[:300]}")
    return r.content


@app.get("/")
def home():
    return FileResponse("static/index.html")


@app.post("/ask")
async def ask(audio: UploadFile = File(None), text: str = Form(None), lang: str = Form("hi-IN")):
    """Returns every pipeline stage with its own timing, so the UI can show the trace in the demo video."""
    steps = []
    t = time.time()
    lap = lambda: round(time.time() - t, 2)
    try:
        if audio is not None:
            s = stt(await audio.read(), lang)
            text = s["transcript"]
            steps.append({"stage": "Gnani Prisma v3.0 · STT", "out": text,
                          "lang": s.get("detected_language_code", lang), "s": lap()})
        else:
            steps.append({"stage": "Typed text (STT skipped)", "out": text or "", "s": 0})
        if not text:
            return JSONResponse({"error": "आवाज़ साफ़ नहीं आई, फिर से बोलिए।"}, status_code=400)
        t = time.time()
        res = answer(text)
        u = res["understood"]
        steps.append({"stage": f"Intent · {'Evon' if u['parser'] == 'evon' else 'keyword parser'}",
                      "out": f"{u['intent']} · crop={u['crop'] or '-'} · place={res['place']}", "s": lap()})
        if res.get("prices"):
            steps.append({"stage": "Mandi data · " + ("synthetic demo data" if res.get("data_source") == "demo" else "Agmarknet"),
                          "out": f"{len(res['prices'])} mandis", "s": 0})
        if res.get("weather"):
            steps.append({"stage": "Weather · Open-Meteo", "out": "3-day forecast", "s": 0})
        t = time.time()
        audio_b64, tts_error = None, None
        try:
            audio_b64 = base64.b64encode(tts(res["reply"])).decode()
            steps.append({"stage": "Gnani Timbre v3.0 · TTS", "out": os.getenv("TIMBRE_VOICE", "Shivani"), "s": lap()})
        except Exception as e:  # still show the text answer if TTS fails
            tts_error = str(e)
            steps.append({"stage": "Gnani Timbre v3.0 · TTS", "out": "failed: " + tts_error[:80], "s": lap()})
        total = round(sum(x["s"] for x in steps), 2)
        return {"transcript": text, **res, "audio_b64": audio_b64, "tts_error": tts_error,
                "steps": steps, "timings": {"total": total}}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)
